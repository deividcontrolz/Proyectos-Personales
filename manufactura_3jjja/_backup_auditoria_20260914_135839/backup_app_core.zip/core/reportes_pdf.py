# -*- coding: utf-8 -*-
"""
reportes_pdf.py - Generacion de Reportes PDF
Manufacturera de Calzado 3-JJJ-A

Genera reportes PDF de:
  - Usuarios registrados
  - Modelos de calzado
  - Lotes de produccion
  - Incidentes
  - Materiales
  - Etapas de produccion

Django 4.2 compatible - Windows 7
"""

import io
from datetime import datetime
from django.http import HttpResponse
from django.utils import timezone

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm, mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, 
    Image, PageBreak, KeepTogether
)
from reportlab.platypus.flowables import HRFlowable

from .models import (
    Usuario, Modelo, Material, LoteProduccion, Etapa, 
    RegistroEtapa, Incidente, Maquinaria, MaterialModelo
)


# ============================================================
# ESTILOS COMUNES
# ============================================================
def get_estilos():
    """Devuelve los estilos personalizados para los PDFs."""
    styles = getSampleStyleSheet()

    # Estilo para titulo principal
    styles.add(ParagraphStyle(
        name='TituloPrincipal',
        fontName='Helvetica-Bold',
        fontSize=18,
        textColor=colors.HexColor('#059669'),
        alignment=TA_CENTER,
        spaceAfter=20,
        spaceBefore=10,
    ))

    # Estilo para subtitulo
    styles.add(ParagraphStyle(
        name='Subtitulo',
        fontName='Helvetica-Bold',
        fontSize=14,
        textColor=colors.HexColor('#334155'),
        alignment=TA_LEFT,
        spaceAfter=12,
        spaceBefore=12,
    ))

    # Estilo para fecha/encabezado
    styles.add(ParagraphStyle(
        name='FechaHeader',
        fontName='Helvetica',
        fontSize=9,
        textColor=colors.HexColor('#64748b'),
        alignment=TA_RIGHT,
    ))

    # Estilo para footer
    styles.add(ParagraphStyle(
        name='Footer',
        fontName='Helvetica',
        fontSize=8,
        textColor=colors.HexColor('#94a3b8'),
        alignment=TA_CENTER,
    ))

    return styles


# ============================================================
# FUNCION AUXILIAR: CREAR TABLA CON ESTILO
# ============================================================
def crear_tabla_pdf(datos, col_widths=None, estilo_personalizado=None):
    """
    Crea una tabla PDF con estilo profesional.

    Args:
        datos: Lista de listas con los datos (primera fila = headers)
        col_widths: Lista de anchos de columnas (opcional)
        estilo_personalizado: Lista de tuplas de estilo adicional
    """
    tabla = Table(datos, colWidths=col_widths, repeatRows=1)

    # Estilo base
    estilo_base = [
        # Header
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#059669')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('VALIGN', (0, 0), (-1, 0), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('TOPPADDING', (0, 0), (-1, 0), 10),

        # Body
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 1), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
        ('TOPPADDING', (0, 1), (-1, -1), 8),

        # Grid
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
        ('LINEBELOW', (0, 0), (-1, 0), 1.5, colors.HexColor('#059669')),

        # Alternar colores de filas
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f8fafc')),
    ]

    # Agregar filas alternadas
    for i in range(1, len(datos)):
        if i % 2 == 0:
            estilo_base.append(('BACKGROUND', (0, i), (-1, i), colors.HexColor('#f1f5f9')))

    if estilo_personalizado:
        estilo_base.extend(estilo_personalizado)

    tabla.setStyle(TableStyle(estilo_base))
    return tabla


# ============================================================
# FUNCION AUXILIAR: ENCABEZADO Y PIE DE PAGINA
# ============================================================
def agregar_encabezado(elements, styles, titulo, subtitulo=None):
    """Agrega encabezado estandar al PDF."""
    # Fecha y hora
    fecha_actual = timezone.now().strftime('%d/%m/%Y %H:%M')
    elements.append(Paragraph(f'Generado: {fecha_actual}', styles['FechaHeader']))
    elements.append(Spacer(1, 5))

    # Titulo
    elements.append(Paragraph(titulo, styles['TituloPrincipal']))

    if subtitulo:
        elements.append(Paragraph(subtitulo, styles['Subtitulo']))

    # Linea separadora
    elements.append(HRFlowable(width='100%', thickness=1, color=colors.HexColor('#059669')))
    elements.append(Spacer(1, 15))


def agregar_footer(canvas, doc):
    """Agrega pie de pagina a cada hoja."""
    canvas.saveState()
    canvas.setFont('Helvetica', 8)
    canvas.setFillColor(colors.HexColor('#94a3b8'))

    # Texto izquierda
    canvas.drawString(2*cm, 1.5*cm, 'Manufacturera de Calzado 3-JJJ-A')

    # Texto centro
    canvas.drawCentredString(A4[0]/2, 1.5*cm, 'Sistema de Gestion de Produccion')

    # Numero de pagina
    canvas.drawRightString(A4[0]-2*cm, 1.5*cm, f'Pagina {doc.page}')

    canvas.restoreState()


# ============================================================
# 1. REPORTE: USUARIOS REGISTRADOS
# ============================================================
def generar_reporte_usuarios(request, rol_filtro=None, estado_filtro=None):
    """
    Genera un PDF con el listado de usuarios registrados.

    Args:
        rol_filtro: Filtrar por rol (opcional)
        estado_filtro: 'activo', 'inactivo' o None
    """
    # Obtener datos
    usuarios = Usuario.objects.all().order_by('-fecha_registro')

    if rol_filtro:
        usuarios = usuarios.filter(rol=rol_filtro)
    if estado_filtro == 'activo':
        usuarios = usuarios.filter(is_active=True)
    elif estado_filtro == 'inactivo':
        usuarios = usuarios.filter(is_active=False)

    # Crear buffer
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2.5*cm
    )

    elements = []
    styles = get_estilos()

    # Encabezado
    titulo = 'Reporte de Usuarios Registrados'
    if rol_filtro:
        titulo += f' - Rol: {rol_filtro}'
    if estado_filtro:
        titulo += f' ({estado_filtro.title()})'

    agregar_encabezado(elements, styles, titulo, f'Total de usuarios: {usuarios.count()}')

    # Preparar datos de la tabla
    datos = [['Usuario', 'Nombre Completo', 'Rol', 'Etapa', 'Estado', 'Fecha Registro']]

    for u in usuarios:
        etapa = u.etapa_asignada.nombre_etapa if u.etapa_asignada else 'N/A'
        estado = 'Activo' if u.is_active else 'Inactivo'
        fecha = u.fecha_registro.strftime('%d/%m/%Y')

        datos.append([
            u.id_usuario,
            u.nombre_completo,
            u.get_rol_display(),
            etapa,
            estado,
            fecha
        ])

    # Crear tabla
    col_widths = [3.5*cm, 5*cm, 3.5*cm, 3*cm, 2.5*cm, 2.5*cm]
    tabla = crear_tabla_pdf(datos, col_widths)
    elements.append(tabla)

    # Estadisticas resumen
    elements.append(Spacer(1, 20))
    elements.append(Paragraph('Resumen por Rol', styles['Subtitulo']))

    resumen_datos = [['Rol', 'Cantidad']]
    from .models import ROLES_CHOICES
    for rol_codigo, rol_nombre in ROLES_CHOICES:
        cantidad = usuarios.filter(rol=rol_codigo).count()
        resumen_datos.append([rol_nombre, str(cantidad)])

    resumen_tabla = crear_tabla_pdf(resumen_datos, [8*cm, 4*cm])
    elements.append(resumen_tabla)

    # Construir PDF
    doc.build(elements, onFirstPage=agregar_footer, onLaterPages=agregar_footer)

    # Preparar respuesta
    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="reporte_usuarios_{timezone.now().strftime("%Y%m%d_%H%M")}.pdf"'
    buffer.close()

    return response


# ============================================================
# 2. REPORTE: MODELOS DE CALZADO
# ============================================================
def generar_reporte_modelos(request):
    """Genera un PDF con el catalogo de modelos de calzado."""
    modelos = Modelo.objects.all().order_by('-fecha_registro')

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2.5*cm
    )

    elements = []
    styles = get_estilos()

    agregar_encabezado(elements, styles, 'Catalogo de Modelos de Calzado', f'Total de modelos: {modelos.count()}')

    datos = [['ID Modelo', 'Nombre', 'Materiales', 'Fecha Registro']]

    for m in modelos:
        # Obtener materiales del modelo
        materiales = MaterialModelo.objects.filter(id_modelo=m).select_related('id_material')
        mats_texto = ', '.join([f'{mm.id_material.nombre_material} ({mm.cantidad_por_par})' for mm in materiales]) or 'Sin materiales'

        datos.append([
            m.id_modelo,
            m.nombre,
            mats_texto[:60] + '...' if len(mats_texto) > 60 else mats_texto,
            m.fecha_registro.strftime('%d/%m/%Y')
        ])

    col_widths = [3.5*cm, 4*cm, 7*cm, 2.5*cm]
    tabla = crear_tabla_pdf(datos, col_widths)
    elements.append(tabla)

    doc.build(elements, onFirstPage=agregar_footer, onLaterPages=agregar_footer)

    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="reporte_modelos_{timezone.now().strftime("%Y%m%d_%H%M")}.pdf"'
    buffer.close()

    return response


# ============================================================
# 3. REPORTE: LOTES DE PRODUCCION
# ============================================================
def generar_reporte_lotes(request, estado=None):
    """Genera un PDF con los lotes de produccion."""
    lotes = LoteProduccion.objects.select_related('id_modelo').all().order_by('-fecha_creacion')

    if estado:
        lotes = lotes.filter(estado_actual=estado)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(A4), rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2.5*cm
    )

    elements = []
    styles = get_estilos()

    agregar_encabezado(elements, styles, 'Reporte de Lotes de Produccion', f'Total de lotes: {lotes.count()}')

    datos = [['ID Lote', 'Modelo', 'Cantidad Solicitada', 'Estado', 'Fecha Creacion']]

    for l in lotes:
        datos.append([
            l.id_lote,
            l.id_modelo.nombre,
            str(l.cant_solicitada),
            l.estado_actual,
            l.fecha_creacion.strftime('%d/%m/%Y %H:%M')
        ])

    col_widths = [4*cm, 5*cm, 4*cm, 3*cm, 4*cm]
    tabla = crear_tabla_pdf(datos, col_widths)
    elements.append(tabla)

    doc.build(elements, onFirstPage=agregar_footer, onLaterPages=agregar_footer)

    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="reporte_lotes_{timezone.now().strftime("%Y%m%d_%H%M")}.pdf"'
    buffer.close()

    return response


# ============================================================
# 4. REPORTE: INCIDENTES
# ============================================================
def generar_reporte_incidentes(request, estado=None, fecha_desde=None, fecha_hasta=None):
    """Genera un PDF con el historial de incidentes."""
    incidentes = Incidente.objects.select_related('id_usuario_reporta', 'id_etapa').all().order_by('-fecha_reporte')

    if estado:
        incidentes = incidentes.filter(estado=estado)
    if fecha_desde:
        incidentes = incidentes.filter(fecha_reporte__date__gte=fecha_desde)
    if fecha_hasta:
        incidentes = incidentes.filter(fecha_reporte__date__lte=fecha_hasta)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(A4), rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2.5*cm
    )

    elements = []
    styles = get_estilos()

    agregar_encabezado(elements, styles, 'Reporte de Incidentes', f'Total de incidentes: {incidentes.count()}')

    datos = [['ID', 'Tipo', 'Severidad', 'Estado', 'Etapa', 'Reportado por', 'Fecha']]

    for inc in incidentes:
        datos.append([
            f'#{inc.id_incidente}',
            inc.get_tipo_incidente_display(),
            inc.get_severidad_display(),
            inc.get_estado_display(),
            inc.id_etapa.nombre_etapa if inc.id_etapa else 'N/A',
            inc.id_usuario_reporta.nombre_completo,
            inc.fecha_reporte.strftime('%d/%m/%Y %H:%M')
        ])

    col_widths = [2*cm, 4*cm, 2.5*cm, 2.5*cm, 3*cm, 4*cm, 3*cm]
    tabla = crear_tabla_pdf(datos, col_widths)
    elements.append(tabla)

    # Estadisticas
    elements.append(Spacer(1, 20))
    elements.append(Paragraph('Resumen por Estado', styles['Subtitulo']))

    estados_datos = [['Estado', 'Cantidad']]
    for estado_codigo, estado_nombre in ESTADO_INCIDENTE_CHOICES:
        cantidad = incidentes.filter(estado=estado_codigo).count()
        estados_datos.append([estado_nombre, str(cantidad)])

    estados_tabla = crear_tabla_pdf(estados_datos, [6*cm, 3*cm])
    elements.append(estados_tabla)

    doc.build(elements, onFirstPage=agregar_footer, onLaterPages=agregar_footer)

    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="reporte_incidentes_{timezone.now().strftime("%Y%m%d_%H%M")}.pdf"'
    buffer.close()

    return response


# ============================================================
# 5. REPORTE: MATERIALES
# ============================================================
def generar_reporte_materiales(request):
    """Genera un PDF con el inventario de materiales."""
    materiales = Material.objects.all().order_by('nombre_material')

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2.5*cm
    )

    elements = []
    styles = get_estilos()

    agregar_encabezado(elements, styles, 'Reporte de Materiales', f'Total de materiales: {materiales.count()}')

    datos = [['ID', 'Nombre Material', 'Unidad de Medida', 'Usado en Modelos']]

    for m in materiales:
        # Contar en cuantos modelos se usa
        usado_en = MaterialModelo.objects.filter(id_material=m).count()

        datos.append([
            str(m.id_material),
            m.nombre_material,
            m.unidad_medida,
            str(usado_en)
        ])

    col_widths = [2.5*cm, 6*cm, 3.5*cm, 3.5*cm]
    tabla = crear_tabla_pdf(datos, col_widths)
    elements.append(tabla)

    doc.build(elements, onFirstPage=agregar_footer, onLaterPages=agregar_footer)

    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="reporte_materiales_{timezone.now().strftime("%Y%m%d_%H%M")}.pdf"'
    buffer.close()

    return response


# ============================================================
# 6. REPORTE: ETAPAS DE PRODUCCION
# ============================================================
def generar_reporte_etapas(request):
    """Genera un PDF con las etapas de produccion y sus estadisticas."""
    etapas = Etapa.objects.all().order_by('secuencia')

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2.5*cm
    )

    elements = []
    styles = get_estilos()

    agregar_encabezado(elements, styles, 'Reporte de Etapas de Produccion', f'Total de etapas: {etapas.count()}')

    datos = [['Secuencia', 'ID Etapa', 'Nombre', 'Operarios Asignados', 'Maquinas', 'Registros']]

    for e in etapas:
        operarios = Usuario.objects.filter(etapa_asignada=e).count()
        maquinas = Maquinaria.objects.filter(id_etapa=e).count()
        registros = RegistroEtapa.objects.filter(id_etapa=e).count()

        datos.append([
            str(e.secuencia),
            e.id_etapa,
            e.nombre_etapa,
            str(operarios),
            str(maquinas),
            str(registros)
        ])

    col_widths = [2.5*cm, 3.5*cm, 4*cm, 3*cm, 2.5*cm, 2.5*cm]
    tabla = crear_tabla_pdf(datos, col_widths)
    elements.append(tabla)

    doc.build(elements, onFirstPage=agregar_footer, onLaterPages=agregar_footer)

    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="reporte_etapas_{timezone.now().strftime("%Y%m%d_%H%M")}.pdf"'
    buffer.close()

    return response
